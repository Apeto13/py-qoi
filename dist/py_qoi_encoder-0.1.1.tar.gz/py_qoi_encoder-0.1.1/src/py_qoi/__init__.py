
__version__ = "0.1.0"

from .qoi import encode, decode, load_qoi, save_qoi
